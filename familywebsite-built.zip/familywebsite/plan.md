# The Nyarko’s Home — Implementation Plan

## Design exploration
- **Warm editorial family archive** — 0.06
- **Modern botanical scrapbook** — 0.08
- **Quiet heritage journal** — 0.07

### Chosen direction: Warm editorial family archive

**Design Movement:** Contemporary editorial publishing with tactile scrapbook details and a West African-inspired warm neutral palette.

**Core Principles:**
1. Make the family name and story feel like the cover of a treasured archive.
2. Use asymmetry, layered paper panels, and generous margins instead of generic centered grids.
3. Keep every interaction friendly and legible for all generations.
4. Pair polished typography with small handmade details so the site feels personal, not corporate.

**Color Philosophy:** Deep ink green anchors trust and belonging; terracotta and saffron add warmth and celebration; parchment backgrounds make content feel archival without becoming precious.

**Layout Paradigm:** Editorial split layouts and offset card clusters. Content alternates between full-bleed color bands and narrow reading columns, with key actions positioned like captions in a family album.

**Signature Elements:** A circular family seal, paper-note cards with visible tape, and a timeline rule that feels like a stitched thread through the family story.

**Interaction Philosophy:** Clear, forgiving actions with tangible feedback. Buttons feel like labels or stamps; cards lift subtly on hover; reduced-motion users get the same clarity without movement.

**Animation:** Short, low-distance easing for route changes, hover lifts, and hero ornament drift. No essential information depends on animation. Respect `prefers-reduced-motion`.

**Typography System:** `DM Serif Display` for the family name, page titles, and story headings; `Manrope` for UI, metadata, and body copy; handwritten `Caveat` only for notes-board messages.

**Brand Essence:** A private digital hearth for the Nyarko family to remember, celebrate, and stay close. Personality: warm, grounded, celebratory.

**Brand Voice:** Headlines sound like invitations to belong; CTAs sound practical and welcoming. Example lines: “Keep the story close.” / “Add your voice to the board.”

**Wordmark & Logo:** A compact family seal: an abstract roofline wrapped by a circular thread, paired with a serif wordmark.

**Signature Brand Color:** Ink green `#163a32`, an ownable color that feels botanical, grounded, and distinct from generic navy family sites.

## Implementation

- Preserve the supplied static architecture: `index.html`, `css/style.css`, and `js/app.js`.
- Keep hash routing and localStorage behaviors for notes, RSVPs, and theme preferences.
- Rebuild the shell and page templates with semantic sections, responsive layouts, focus states, and a route manifest at `/manus-routes.json`.
- Keep the site dependency-free beyond Google Fonts loaded by the HTML page.
- Use CSS-only decorative shapes and gradients instead of placeholder stock images, so the site remains fast and personalizable.

## Project structure

- `index.html`: document shell, navigation, footer, font loading, and route-manifest link.
- `css/style.css`: tokens, responsive layout, components, decorative system, and accessibility states.
- `js/app.js`: content data, route rendering, forms, notes board, RSVPs, and theme/menu interactions.
- `public/manus-routes.json`: static route declaration for preview and deployment tooling.
