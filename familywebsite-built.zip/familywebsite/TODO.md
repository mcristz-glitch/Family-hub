# TODO

## Complete the family website shell and navigation
- Build the family website from the supplied archive.
- Preserve routes for Home, About, Members, Gallery, Events, Notes, News, and Contact Admin.
- Provide mobile navigation, theme switching, skip-link access, active-route state, and a responsive footer.

## Deliver the family-focused homepage and content pages
- Present the family name, welcome message, motto, story CTA, upcoming events CTA, navigation cards, upcoming events, notes preview, and latest news.
- Provide pages for family history, values, members by generation, gallery albums, events, news, privacy, and admin placeholder.
- Keep supplied sample content editable in one JavaScript data layer.

## Preserve interactive family tools
- Allow family members to add notes with a name, message, and color; save notes on the current device.
- Allow RSVP toggles for listed events and persist them locally.
- Validate the contact form and open a pre-filled email to the administrator.
- Keep reduced-motion and keyboard-focus behavior accessible.

## Add route metadata and delivery-ready structure
- Serve `/manus-routes.json` with the complete page route set.
- Keep the implementation dependency-free and runnable as a static site.

## Protect the admin page
- Require the custom password `iammrkojo` before showing the admin view.
- Keep the authenticated state in the current browser session and provide a sign-out action.
- Keep the static-preview limitation visible so production can replace it with server-side authentication.
